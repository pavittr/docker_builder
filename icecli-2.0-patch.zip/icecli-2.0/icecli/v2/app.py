# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2011, 2013. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
__author__ = 'asyousse'
#ccs cli v2.0 invokes rest interface of ccs api v2.0

VERSION = 2.0

import argparse
import os
import sys
import traceback
import commands   #implementation of cli commands
import extensions


def _init_parsers():
    #Build top parser
    #Note: each arg must have dest value defined to decouple rest of code from arg name.
    global parser
    parser = argparse.ArgumentParser(prog=commands.PROG_NAME)
    parser.add_argument('--verbose', '-v', action="store_true", dest='verbose', help='display additional debug info')
    #create a mutually exclusive group for --cloud and --local
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--cloud', help="execute command against container cloud service, default", action="store_true", dest='cloud')
    group.add_argument('--local', '-L', help="execute any local docker host command. For list of available commands run \'docker help\'", action="store_true", dest='local')
    #parser.add_argument('help',  action="store", dest='help', help='container cloud service url')

    #Build a subparser for each command
    help_title=''   #help_title=commands.PROG_NAME+' '
    help_title+='cloud commands'+', for specific command help follow the command by -h, to list local docker commands run \'docker -h\' or \'ice --local -h\''
    subparsers = parser.add_subparsers(help=help_title, dest='subparser_name')

    #login parser using api key credential
    global login_parser
    login_parser = subparsers.add_parser ('login', help='login to container cloud service')
    lgroup = login_parser.add_mutually_exclusive_group()
    lgroup.add_argument('--cf', action="store_true", dest='cf', help='use Bluemix cf login, default (Bluemix params are used, api key ignored)')
    lgroup.add_argument('--key', '-k', action="store", dest='api_key', help='secret key string (ignored when Bluemix login is used)')
    login_parser.add_argument('--host', '-H', action="store", dest='host', help='container cloud service host, or url')
    login_parser.add_argument('--registry', '-R', action="store", dest='reg_host', help='container cloud registry host')
    login_parser.add_argument('--user', '-u', action="store", dest='user', help='Bluemix user id/email')
    login_parser.add_argument('--psswd', '-p', action="store", dest='psswd', help='Bluemix password')
    login_parser.add_argument('--org', '-o', action="store", dest='org', help='Bluemix organization')
    login_parser.add_argument('--space', '-s', action="store", dest='space', help='Bluemix space')
    login_parser.add_argument('--api', '-a', action="store", dest='api_url', help='Bluemix API endpoint')

    #login command parser using tenant/user/psswd credential
    global tlogin_parser
    tlogin_parser = subparsers.add_parser ('tlogin', help='tenant login, not available for Bluemix Containers')
    tlogin_parser.add_argument('--tenant', '-t', action="store", dest='tenant', help='tenant name')
    tlogin_parser.add_argument('--user', '-u', action="store", dest='user', help='user name')
    tlogin_parser.add_argument('--psswd', '-p', action="store", dest='psswd', help='password')
    tlogin_parser.add_argument('--host', '-H', action="store", dest='host', help='container cloud service host')
    tlogin_parser.add_argument('--registry', '-R', action="store", dest='reg_host', help='container cloud registry host')
    ###login_parser.set_defaults(func=login_func)   ##another approach for routing logic to login_func() when parser.parse_args() is called and this subparser succeeds.

    #ps command parser
    global ps_parser
    ps_parser = subparsers.add_parser ('ps', help='list containers in container cloud')
    ps_parser.add_argument('--all', '-a', action="store_true", dest='all', help='list all containers, only running containers are shown by default')
    ps_parser.add_argument('--size', '-s', action="store_true", dest='size', help='list container sizes')
    ps_parser.add_argument('--limit', '-l', action="store", type=int, dest='num', help='list last NUM created containers')
    ps_parser.add_argument('--quiet', '-q', action="store_true", dest='quiet', help='display only container ids')

    #run command parser
    global run_parser
    run_parser = subparsers.add_parser ('run', help='create and start container in container cloud')
    run_parser.add_argument('--name', '-n', action="store", type=str, dest='name', help='assign a name to the container')
    run_parser.add_argument('--memory', '-m', action="store", type=int, dest='memory', help='memory limit in MB, default is 256')
    #run_parser.add_argument('--cpu-shares', '-c', action="store", type=int, dest='shares', help='CPU shares (relative weight)')
    #run_parser.add_argument('--cpuset', '-s', action="store", type=int, dest='cpus', help='number of CPUs in which to allow execution')
    run_parser.add_argument('--env', '-e', action="append", dest='env', help='set environment variable, ENV is key=value pair')
    run_parser.add_argument('--publish', '-p', action="append", type=int, dest='port', help='expose PORT')
    run_parser.add_argument('--volume', '-v', action="append", dest='vol', help='mount volume, VOL is VolumeId:ContainerDir pair')
    #run_parser.add_argument('--workdir', '-w', action="store", type=str, dest='workdir', help='working directory')
    run_parser.add_argument('IMAGE',  action="store", help='image to run')
    #run_parser.add_argument('CMD', nargs='*', action="append", help='command & args passed to container to execute')
    run_parser.add_argument('--bind', '-b', action="store", dest='app', help='bind to Bluemix app')

    #inspect command parser
    global inspect_parser
    inspect_parser = subparsers.add_parser ('inspect', help='inspect container details')
    inspect_parser.add_argument('CONTAINER', action="store", help='container name or id')

    #logs command parser
    global logs_parser
    logs_parser = subparsers.add_parser ('logs', help='get container logs')
    logs_parser.add_argument('CONTAINER', action="store", help='container name or id')
    logs_group = logs_parser.add_mutually_exclusive_group()
    logs_group.add_argument('--stdout', '-o', help="get output log, default", action="store_true", dest='stdout')
    logs_group.add_argument('--stderr', '-e', help="get error log", action="store_true", dest='stderr')

    #build parser
    global build_parser
    build_parser = subparsers.add_parser('build', help='build docker image and push to cloud registry')
    build_parser.add_argument('--tag', '-t', action="store", dest='tag', help='repository name to be applied to resulting image')
    #build_parser.add_argument('--no-rm', action="store_true", dest='no_rm', help='remove intermediate containers after a successful build, default is false')
    #build_parser.add_argument('--force-rm', action="store_true", dest='force_rm', help='always remove intermediate containers even after unsuccessful builds, default is false')
    build_parser.add_argument('--no-cache', action="store_true", dest='no_cache', help='do not use cache when building the image')
    build_parser.add_argument('--pull', '-p', action="store_true", dest='pull', help='attempt to pull base image from registry even if cached')
    build_parser.add_argument('--quiet', '-q', action="store_true", dest='quiet', help='suppress the verbose output generated by the containers')
    build_parser.add_argument('PATH',  action="store", help='path to build context containing Dockerfile on local host')
    #TODO support for git url

    #start command parser
    global start_parser
    start_parser = subparsers.add_parser ('start', help='run existing container')
    start_parser.add_argument('CONTAINER', action="store", help='container name or id')

    #stop command parser
    global stop_parser
    stop_parser = subparsers.add_parser ('stop', help='stop running container')
    stop_parser.add_argument('CONTAINER', action="store", help='container name or id')
    stop_parser.add_argument('--time', '-t', action="store", type=int, dest='secs', help='seconds to wait before killing container')

    #restart command parser
    global restart_parser
    restart_parser = subparsers.add_parser ('restart', help='restart running container')
    restart_parser.add_argument('CONTAINER', action="store", help='container name or id')
    restart_parser.add_argument('--time', '-t', action="store", type=int, dest='secs', help='seconds to wait before killing container')

    #pause command parser
    global pause_parser
    pause_parser = subparsers.add_parser ('pause', help='pause existing container')
    pause_parser.add_argument('CONTAINER', action="store", help='container name or id')

    #unpause command parser
    global unpause_parser
    unpause_parser = subparsers.add_parser ('unpause', help='unpause existing container')
    unpause_parser.add_argument('CONTAINER', action="store", help='container name or id')

    #rm command parser
    global rm_parser
    rm_parser = subparsers.add_parser ('rm', help='remove existing container')
    rm_parser.add_argument('CONTAINER', action="store", help='container name or id')

    #images command parser
    global images_parser
    images_parser = subparsers.add_parser ('images', help='list images registered in container cloud')

    '''
    #imagereg command parser
    global imagereg_parser
    imagereg_parser = subparsers.add_parser ('imagereg', help='register image from docker hub or private docker registry in container cloud')
    imagereg_parser.add_argument('IMAGE', action="store", help='image reference')
    #imagereg_parser.add_argument('--fast', '-f', help="fast start flag", action="store_true", dest='fast')

    #imageupdate command parser
    global imageupdate_parser
    imageupdate_parser = subparsers.add_parser ('imageupdate', help='update registered image')
    imageupdate_parser.add_argument('IMAGE_ID', action="store", help='image id')
    imageupdate_parser.add_argument('IMAGE', action="store", help='new image reference')
    #imageupdate_parser.add_argument('--fast', '-f', help="fast start flag", action="store_true", dest='fast')
    '''

    #rmi command parser
    global rmi_parser
    rmi_parser = subparsers.add_parser ('rmi', help='remove image from container cloud registry')
    rmi_parser.add_argument('IMAGE', action="store", help='name of image to remove')
    rmi_parser.add_argument('--registry', '-R', action="store", help='registry host')
    rmi_parser.add_argument('--key', '-k', dest='psswd', action="store", help='registry api key or token')

    #search command parser -- search against ice registry
    global search_parser
    search_parser = subparsers.add_parser ('search', help='search image registry')
    search_parser.add_argument('TERM', nargs='?', action="store", help='TERM to search for in image name')
    search_parser.add_argument('--registry', '-R', action="store", help='registry host to search')
    search_parser.add_argument('--key', '-k', dest='psswd', action="store", help='registry key or token')

    #info command parser
    global info_parser
    info_parser = subparsers.add_parser ('info', help='display system info')

    #
    #ip command parsers ---- ip {list, bind, unbind, request, release}
    #
    global ip_parser
    ip_help_text='floating-ips management commands, for specific command help use: ice ip <command> -h'
    ip_parser = subparsers.add_parser ('ip', help='manage floating-ips')
    ip_subparsers = ip_parser.add_subparsers(help=ip_help_text, dest='ip_subparser_name')

    #ip list command parser
    ip_list_parser = ip_subparsers.add_parser ('list', help='list floating ips, defaults to available only ips')
    ip_list_parser.add_argument('--all', '-a', help="list all ips, available ips only are shown by default", action="store_true", dest='all')

    #ip bind command parser
    ip_bind_parser = ip_subparsers.add_parser ('bind', help='bind floating ip to container')
    ip_bind_parser.add_argument('ADDRESS', help="ip address", type=str, action="store")
    ip_bind_parser.add_argument('CONTAINER', help="container id or name", type=str, action="store")

    #ip unbind command parser
    ip_unbind_parser = ip_subparsers.add_parser ('unbind', help='unbind floating ip from container')
    ip_unbind_parser.add_argument('ADDRESS', help="ip address", type=str, action="store")
    ip_unbind_parser.add_argument('CONTAINER', help="container id or name", type=str, action="store")

    #ip request command parser
    ip_request_parser = ip_subparsers.add_parser ('request', help='request a new floating ip')

    #ip release command parser
    ip_release_parser = ip_subparsers.add_parser ('release', help='release floating ip back to general pool')
    ip_release_parser.add_argument('ADDRESS', help="ip address", type=str, action="store")

    #
    #group command parsers ---- group {list, create, rm, update, health}
    #
    global group_parser
    group_help_text='auto-scaling groups management commands, for specific command help use: ice group <command> -h'
    group_parser = subparsers.add_parser ('group', help='manage auto-scaling groups')
    group_subparsers = group_parser.add_subparsers(help=group_help_text, dest='group_subparser_name')

    #group list command parser
    group_list_parser = group_subparsers.add_parser ('list', help='list auto-scaling groups')

    #group create command parser
    group_create_parser = group_subparsers.add_parser ('create', help='create auto-scaling group')
    group_create_parser.add_argument('--name', '-n', action="store", type=str, dest='name', help='assign a name to the group')
    group_create_parser.add_argument('--memory', '-m', action="store", type=int, dest='memory', help='memory limit in MB, default is 256')
    #group_create_parser.add_argument('--cpu-shares', '-c', action="store", type=int, dest='shares', help='CPU shares (relative weight)')
    #group_create_parser.add_argument('--cpuset', '-s', action="store", type=int, dest='cpus', help='number of CPUs in which to allow execution')
    group_create_parser.add_argument('--env', '-e', action="append", dest='env', help='set environment variable, key=value pair')
    group_create_parser.add_argument('--publish', '-p', action="store", type=int, dest='port', help='expose PORT for http traffic')
    group_create_parser.add_argument('--volume', '-v', action="append", dest='vol', help='mount volume, VOL is VolumeId:ContainerDir pair')
    #group_create_parser.add_argument('--workdir', '-w', action="store", type=str, dest='workdir', help='working directory')
    group_create_parser.add_argument('--min', action="store", dest='min', help='min number of instances, default is 1')
    group_create_parser.add_argument('--max', action="store", dest='max', help='max number of instances, default  is 2')
    group_create_parser.add_argument('--desired', action="store", dest='desired', help='desired number of instances, default is 2')
    group_create_parser.add_argument('--bind', '-b', action="store", dest='app', help='bind to Bluemix app')
    group_create_parser.add_argument('IMAGE',  action="store", help='image to run')
    #group_create_parser.add_argument('CMD', nargs='*', action="append", help='command & args passed to container to execute')


    #group update command parser
    #group_update_parser = group_subparsers.add_parser ('update', help='update auto-scaling group')
    #group_update_parser.add_argument('GROUP', help="group id or name", action="store")
    #group_update_parser.add_argument('--min', action="store", dest='min', help='min number of instances')
    #group_update_parser.add_argument('--max', action="store", dest='max', help='max number of instances')
    #group_update_parser.add_argument('--desired', action="store", dest='desired', help='desired number of instances')

    #group rm command parser
    group_rm_parser = group_subparsers.add_parser ('rm', help='remove auto-scaling group')
    group_rm_parser.add_argument('GROUP', help="group id or name", action="store")

    #group inspect command parser
    group_inspect_parser = group_subparsers.add_parser ('inspect', help='inspect group')
    group_inspect_parser.add_argument('GROUP', help="group id or name", action="store")

    #group health command parser
    #group_health_parser = group_subparsers.add_parser ('health', help='health status for containers in group')
    #group_health_parser.add_argument('GROUP', help="group id or name", action="store")

    #
    #route command parsers
    #
    global route_parser
    route_help_text='Route management commands for container groups, for specific command help use: ice route <command> -h'
    route_parser = subparsers.add_parser ('route', help='manage routing to container groups')
    route_subparsers = route_parser.add_subparsers(help=route_help_text, dest='route_subparser_name')

    #route map command parser
    route_map_parser = route_subparsers.add_parser ('map', help='map route')
    route_map_parser.add_argument('--hostname', '-n', action="store", type=str, dest='host', help='host name for the route')
    route_map_parser.add_argument('--domain', '-d', action="store", type=str, dest='domain', help='domain name for the route')
    route_map_parser.add_argument('GROUP', help="group id or name", action="store")

    #route unmap command parser
    route_unmap_parser = route_subparsers.add_parser ('unmap', help='unmap route')
    route_unmap_parser.add_argument('GROUP', help="group id or name", action="store")
    route_unmap_parser.add_argument('--hostname', '-n', action="store", type=str, dest='host', help='host name for the route')
    route_unmap_parser.add_argument('--domain', '-d', action="store", type=str, dest='domain', help='domain name for the route')

    #
    #volume command parsers
    #
    global volume_parser
    volume_help_text='Volume management commands, for specific command help use: ice volume <command> -h'
    volume_parser = subparsers.add_parser ('volume', help='manage storage volumes')
    volume_subparsers = volume_parser.add_subparsers(help=volume_help_text, dest='volume_subparser_name')

    #volume list command parser
    volume_list_parser = volume_subparsers.add_parser ('list', help='list volumes')

    #volume create command parser
    volume_create_parser = volume_subparsers.add_parser ('create', help='create volume')
    volume_create_parser.add_argument('VOLNAME', help="volume name", action="store")

    #volume rm command parser
    volume_rm_parser = volume_subparsers.add_parser ('rm', help='remove volume')
    volume_rm_parser.add_argument('VOLNAME', help="volume name", action="store")

    #volume inspect command parser
    volume_inspect_parser = volume_subparsers.add_parser ('inspect', help='inspect volume')
    volume_inspect_parser.add_argument('VOLNAME', help="volume name", action="store")

    #namespace command parser
    global namespace_parser
    ns_help_text='Repository namespace management commands, for specific command help use: ice namespace <command> -h'
    namespace_parser = subparsers.add_parser ('namespace', help='manage repository namespace')
    ns_subparsers = namespace_parser.add_subparsers(help=ns_help_text, dest='ns_subparser_name')
    #set-namespace command parser
    setns_parser = ns_subparsers.add_parser ('set', help='set organization repository namespace')
    setns_parser.add_argument('NAME', action="store", type=str, help='repository namespace')
    #get-namespace command parser
    getns_parser = ns_subparsers.add_parser ('get', help='get organization repository namespace')
    #rm-namespace command parser
    #rmns_parser = ns_subparsers.add_parser ('rm', help='remove organization repository namespace')

    #HELP command parser
    global help_parser
    help_parser = subparsers.add_parser ('help', help='provide usage help for a specified command')
    help_parser.add_argument('COMMAND', nargs='?', action="store", type=str, help='command for which to provide usage help')

    #VERSION command parser
    global version_parser
    version_parser = subparsers.add_parser ('version', help='display program version')

    return parser.parse_args()

def help_command(ns):
    if ns.COMMAND:
        cmd = ns.COMMAND
        parser_name = cmd+'_parser'
        help_func=parser_name+'.print_help()'
        if parser_name in globals():
            eval(help_func)
        else:
            sys.stdout.write(cmd+' is not a valid command\n')
            parser.print_help()
            return 2
    else:
        parser.print_help()
    return 0

def ver_command(ns):
    sys.stdout.write(str(VERSION)+'\n')
    return 0

### Main
def main():
    commands.load_config()

    local_flag=False
    for x in sys.argv:
        if x == '--local' or x == '-L':
            sys.argv.remove(x)
            local_flag=True

    #if target is local execution, pass args to docker
    if local_flag==True:
        #invoke original docker cli
        sys.stdout.write("Target is local host. Invoking docker with the given arguments...\n")
        sys.argv[0] = commands.DOCKER_PATH
        #remove --local if present in args
        #sys.argv.remove('--local')  ### NOTE: Special case. Explicit dependency on the arg name '--local'
        commands.debug (sys.argv)
        try:
            os.execvp(commands.DOCKER_PATH, sys.argv)
        except:
            sys.stdout.write ("Could not find or execute "+ commands.DOCKER_PATH +'\n')
            commands.debug_exc()
            exit(1)

    commands.debug("Target is container cloud. Invoking cloud service...\n")
    args=_init_parsers()
    #if parsing error (such as wrong arg mix) or if help (-h or --help) is detected, a help message is printed by the parser and code exits at this point.

    #check for common args
    #NOTICE: common args at ice level should not collide with same name args for any ice COMMAND
    if args.verbose:
        commands.VERBOSE = True

    commands.debug(args)

    if extensions.ICE_CLI_PRE_HANDLER != '':
        handler_name='extensions.'+extensions.ICE_CLI_PRE_HANDLER+'(args)'
        try:
            eval(handler_name)
        except:
            commands.debug('Handler execution failed')
            commands.debug_exc()

    #figure out which command subparser fired and route logic accordingly
    #check first for the case of absent command
    r=0   #default err return level == no error
    if not args.subparser_name:
        #no command was given.
        r=commands.no_command(args)
    elif args.subparser_name=='login':
        r=commands.login(args)
    elif args.subparser_name=='tlogin':
        r=commands.tlogin(args)
    elif args.subparser_name=='ps':
        r=commands.ps(args)
    elif args.subparser_name=='run':
        r=commands.run(args)
    elif args.subparser_name=='inspect':
        r=commands.inspect(args)
    elif args.subparser_name=='logs':
        r=commands.logs(args)
    elif args.subparser_name=='build':
        r=commands.build(args)
    elif args.subparser_name=='start':
        r=commands.start(args)
    elif args.subparser_name=='stop':
        r=commands.stop(args)
    elif args.subparser_name=='restart':
        r=commands.restart(args)
    elif args.subparser_name=='pause':
        r=commands.pause(args)
    elif args.subparser_name=='unpause':
        r=commands.unpause(args)
    elif args.subparser_name=='rm':
        r=commands.rm(args)
    elif args.subparser_name=='rmi':
        r=commands.rmi(args)
    elif args.subparser_name=='images':
        r=commands.images(args)
    elif args.subparser_name=='info':
        r=commands.info(args)
    elif args.subparser_name=='search':
        r=commands.search(args)
    elif args.subparser_name=='ip':
        if not args.ip_subparser_name:
            #no command was given
            print("specify ip sub-command")
            r=1
        elif args.ip_subparser_name=='list':
            r=commands.iplist(args)
        elif args.ip_subparser_name=='bind':
            r=commands.ipbind(args)
        elif args.ip_subparser_name=='unbind':
            r=commands.ipunbind(args)
        elif args.ip_subparser_name=='request':
            r=commands.iprequest(args)
        elif args.ip_subparser_name=='release':
            r=commands.iprelease(args)
    elif args.subparser_name=='group':
        if not args.group_subparser_name:
            #no command was given
            print("specify group sub-command")
            r=1
        elif args.group_subparser_name=='list':
            r=commands.group_list(args)
        elif args.group_subparser_name=='create':
            r=commands.group_create(args)
        elif args.group_subparser_name=='rm':
            r=commands.group_rm(args)
        elif args.group_subparser_name=='inspect':
            r=commands.group_inspect(args)
    elif args.subparser_name=='route':
        if not args.route_subparser_name:
            #no command was given
            print("specify route sub-command")
            r=1
        elif args.route_subparser_name=='map':
            r=commands.route_map(args)
        elif args.route_subparser_name=='unmap':
            r=commands.route_unmap(args)
    elif args.subparser_name=='volume':
        if not args.volume_subparser_name:
            #no command was given
            print("specify volume sub-command")
            r=1
        elif args.volume_subparser_name=='list':
            r=commands.volume_list(args)
        elif args.volume_subparser_name=='create':
            r=commands.volume_create(args)
        elif args.volume_subparser_name=='rm':
            r=commands.volume_rm(args)
        elif args.volume_subparser_name=='inspect':
            r=commands.volume_inspect(args)
    elif args.subparser_name=='namespace':
        if not args.ns_subparser_name:
            #no command was given
            print("specify namespace sub-command")
            r=1
        elif args.ns_subparser_name=='set':
            r=commands.set_namespace(args)
        elif args.ns_subparser_name=='get':
            r=commands.get_namespace(args)
    elif args.subparser_name=='help':
        r=help_command(args)
    elif args.subparser_name=='version':
        r=ver_command(args)
    else:
        #No action needed.
        #Parser will catch error and display help message if non of the valid commands was given.
        #This code should not be reached.
        pass

    if extensions.ICE_CLI_POST_HANDLER != '':
        handler_name='extensions.'+extensions.ICE_CLI_POST_HANDLER+'(args)'
        try:
            eval(handler_name)
        except:
            commands.debug('Handler execution failed')
            commands.debug_exc()

    if type(r) is int:
        r2=abs(r) #non -ve exit codes only work on some platforms
    else:
        r2=abs(r[0])
    commands.debug( 'Exit err level = '+str(r2) )
    exit(r2)

if __name__ == '__main__':
    main()



