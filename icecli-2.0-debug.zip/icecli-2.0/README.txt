# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2011, 2013. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

ICE CLI - IBM Container Engine Command Line Interface

Installation Steps:
-------------------
Pre-reqs: python, python setup-tools, python pip,
recommended: python virtualenv

[If this is not the first time to install the tool on this machine, uninstall previous ver first.
Please see below section on un-installation.]

1- Obtain the distribution package (icecli-1.0.zip or icecli-1.0.tar.gz)

2- Install
pip install icecli-1.0.zip
or
pip install icecli-1.0.tar.gz

Now you are ready to use ice to manage containers, images, and floating ips in the cloud.

Example help commands:
ice -h
ice login -h
ice run -h
ice ps -h
ice images -h
ice ip -h

Troubleshooting:
----------------
- If python setuptools is not already installed on your machine, please refer to https://pypi.python.org/pypi/setuptools.

- If docker is not on your path, edit ice-cfg.ini to set the path to your docker executable.

ice-cfg.ini is located in a dir called .ice in your home dir. It is created the first time you run ice and login
successfully. You may alternatively manually create the dir and file.
Example ice-cfg.ini file with docker path set:

[DEFAULT}
docker_path = /usr/bin/docker

- On some Windows platforms, you may need to set the environment variable PYTHONPATH to point at the installed icecli
python scripts. You can do this from administrative console. The path to the installed python scripts is:
<your python home>\Lib\site-packages\cli\v1

- You may set ccs_hor_url and reg_host in the ice-cfg.ini file instead of typing them as options
to the login command or using the defaults built-in.
Example ice-cfg.ini file with these attributes set set:

[DEFAULT}
docker_path = /usr/bin/docker
ccs_host_url = https://api-ice.stage1.ng.bluemix.net/v1.0/containers
reg_host = registry-ice.stage1.ng.bluemix.net


Uninstalling the CLI tool:
--------------------------
Perform either:

pip uninstall icecli

or

Remove the ice python egg. On linux:
rm /usr/local/lib/python2.7/dist-packages/icecli*
(you may need to change the above path if you have a different ver of Python, or installed it in a different location)


Quick Start Guide
-----------------
- Follow installation steps

- Login to the container cloud service using your credentials
ice login --key <API KEY>
(API key is obtained from your service dashboard in BlueMix)

- list available images in the bluemix registry
ice images

- Run a container based on one of the existing images, e.g., ubuntu image
ice run --name my-ubuntu  ubuntu
(Note the returned container id)

- Check the state of your containers
ice ps

- Assign ip address to your container
ice ip request
(note the returned ip ADDRESS)
ice ip bind ADDRESS my-ubuntu


Commands Help
-------------

usage: ice [-h] [--cloud | --local]
                 {login,ps,run,inspect,start,stop,restart,pause,unpause,rm,images,imagereg,imageupdate,rmi,ip}
                 ...

positional arguments:
  {login,ps,run,inspect,start,stop,restart,pause,unpause,rm,images,imagereg,imageupdate,rmi,ip}
                        cloud commands, for specific command help follow the
                        command by -h, for local commands use 'docker -h'
    login               login to container cloud service
    ps                  list containers in container cloud
    run                 create and start container in container cloud
    inspect             inspect container details
    start               run existing container
    stop                stop running container
    restart             restart running container
    pause               pause existing container
    unpause             unpause existing container
    rm                  remove existing container
    images              list images registered in container cloud
    imagereg            register image from docker hub or private docker
                        registry in container cloud
    imageupdate         update registered image
    rmi                 remove image registration from container cloud
    info                display system info
    ip                  manage floating-ips

optional arguments:
  -h, --help            show this help message and exit
  --cloud               command target is container cloud
  --local               command target is local host
  --host URL, -H URL    container cloud service url

-------------------------------------------

usage: ice login [-h] [--host URL] [--key API_KEY]


optional arguments:
  -h, --help            show this help message and exit
  --host URL, -H URL    container cloud service url
  --key API_KEY         API key obtained from BlueMix service dashboard

-------------------------------------------

usage: ice ps [-h] [--all] [--size] [--limit NUM]

optional arguments:
  -h, --help           show this help message and exit
  --all, -a            list all containers, only running containers are shown
                       by default
  --size, -s           list container sizes
  --limit NUM, -l NUM  list last NUM created containers

-------------------------------------------

usage: ice run [-h] [--name NAME] [--memory MEMORY]
                     [--cpu-shares SHARES] [--cpuset CPUS] [--env ENV]
                     [--workdir WORKDIR]
                     IMAGE [CMD [CMD ...]]

positional arguments:
  IMAGE                 image to run
  CMD                   rest of command line passed to container to execute

optional arguments:
  -h, --help            show this help message and exit
  --name NAME, -n NAME  assign a name to the container
  --memory MEMORY, -m MEMORY
                        memory limit in KB, default is 512
  --cpu-shares SHARES, -c SHARES
                        CPU shares (relative weight)
  --cpuset CPUS, -s CPUS
                        number of CPUs in which to allow execution
  --env ENV, -e ENV     set environment variable, key=value pair
  --workdir WORKDIR, -w WORKDIR
                        working directory

-------------------------------------------

usage: ice inspect [-h] CONTAINER

positional arguments:
  CONTAINER   container name or id

optional arguments:
  -h, --help  show this help message and exit

-------------------------------------------

usage: ice start [-h] CONTAINER

positional arguments:
  CONTAINER   container name or id

optional arguments:
  -h, --help  show this help message and exit

-------------------------------------------

usage: ice stop [-h] [--time SECS] CONTAINER

positional arguments:
  CONTAINER             container name or id

optional arguments:
  -h, --help            show this help message and exit
  --time SECS, -t SECS  seconds to wait before killing container

-------------------------------------------

usage: ice restart [-h] [--time SECS] CONTAINER

positional arguments:
  CONTAINER             container name or id

optional arguments:
  -h, --help            show this help message and exit
  --time SECS, -t SECS  seconds to wait before killing container

-------------------------------------------

usage: ice pause [-h] CONTAINER

positional arguments:
  CONTAINER   container name or id

optional arguments:
  -h, --help  show this help message and exit

-------------------------------------------

usage: ice unpause [-h] CONTAINER

positional arguments:
  CONTAINER   container name or id

optional arguments:
  -h, --help  show this help message and exit

-------------------------------------------

usage: ice rm [-h] CONTAINER

positional arguments:
  CONTAINER   container name or id

optional arguments:
  -h, --help  show this help message and exit

-------------------------------------------

usage: ice images [-h]

optional arguments:
  -h, --help  show this help message and exit

-------------------------------------------

usage: ice imagereg [-h] [--fast] IMAGE

positional arguments:
  IMAGE       image name or id

optional arguments:
  -h, --help  show this help message and exit
  --fast, -f  fast start flag

-------------------------------------------

usage: ice rmi [-h] IMAGE

positional arguments:
  IMAGE       image name or id

optional arguments:
  -h, --help  show this help message and exit

-------------------------------------------

usage: ice imageupdate [-h] [--fast] IMAGE

positional arguments:
  IMAGE       image name or id

optional arguments:
  -h, --help  show this help message and exit
  --fast, -f  fast start flag

-------------------------------------------

usage: ice info [-h]

optional arguments:
  -h, --help  show this help message and exit

-------------------------------------------

usage: ice ip [-h] {list,bind,unbind,request,release} ...

positional arguments:
  {list,bind,unbind,request,release}
                        floating-ips management commands, for specific command
                        help follow the command by -h
    list                list floating ips, defaults to available only ips
    bind                bind floating ip to container
    unbind              unbind floating ip from container
    request             request a new floating ip
    release             release floating ip back to general pool

optional arguments:
  -h, --help            show this help message and exit

-------------------------------------------

usage: ice ip list [-h] [--all]

optional arguments:
  -h, --help  show this help message and exit
  --all, -a   list all ips, available ips only are shown by default

-------------------------------------------

usage: ice ip bind [-h] ADDRESS CONTAINER

positional arguments:
  ADDRESS     ip address
  CONTAINER   container id or name

optional arguments:
  -h, --help  show this help message and exit

-------------------------------------------

usage: ice ip unbind [-h] ADDRESS CONTAINER

positional arguments:
  ADDRESS     ip address
  CONTAINER   container id or name

optional arguments:
  -h, --help  show this help message and exit

-------------------------------------------

usage: ice ip request [-h]

optional arguments:
  -h, --help  show this help message and exit

-------------------------------------------

usage: ice ip release [-h] ADDRESS

positional arguments:
  ADDRESS     ip address

optional arguments:
  -h, --help  show this help message and exit
