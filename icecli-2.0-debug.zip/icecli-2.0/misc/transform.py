#internal tool
#usage: python transform.py in_out_file search_string replace_string
__author__ = 'asyousse'
import os
import sys
if __name__ == '__main__':
    if len(sys.argv) != 4 :
        print('Usage: python transform.py in_out_file search_string replace_string')
        exit(1)
    fname = sys.argv[1]
    ss = sys.argv[2]
    rs = sys.argv[3]
    print('Input/Output File:', fname)
    print('Search String:', ss)
    print('Replace String:', rs)
    ftemp = "tmp_transform.txt"
    fi = open(fname,"r")
    fo = open(ftemp, "w")
    for line in fi:
        fo.write( line.replace(ss,rs) )
    fi.close()
    fo.close()
    os.remove(fname)
    os.rename(ftemp, fname)
    exit(0)