# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2011, 2013. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

from setuptools import setup

setup(
    # Application name:
    name="icecli",

    # Version number (initial):
    version="2.0",

    # Application author details:
    author="Alaa Youssef",
    author_email="asyousse@us.ibm.com",

    # Packages
    packages=["icecli"],

    entry_points = {
        "console_scripts": ['ice = icecli.v2.app:main']
    },

    # Include additional files into the package
    include_package_data=True,

    # Details - Put public download url here, put tar file at that place
    url="http://mybluemix.net/alchemy/ccscli_v2/",

    #
    # license="LICENSE.txt",
    description="IBM Container Engine CLI.",

    # long_description=open("README.txt").read(),

    # Dependent packages (distributions)
    install_requires=[
        "argparse",
        "configparser==3.2.0.post3",
        "requests==2.4.3",
    ],
)